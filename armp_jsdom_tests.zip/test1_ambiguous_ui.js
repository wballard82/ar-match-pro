// TEST 1 — Ambiguous allocation UI: chip rendering + choose-combination flow
const { boot, sleep, check, eq, summary } = require('./harness');

(async () => {
  const h = await boot();
  await h.login('pro');
  const w = h.window, d = w.document;

  // Seed: two distinct invoice combos tie to a $3,000 lump (1000+2000 vs 1200+1800),
  // total of all open invoices ≠ payment so the "all invoices" shortcut can't fire.
  h.g(`
    INV = [
      {a:'100200', c:'ACME CORP', i:'5100000001', po:'PO-1', so:'', d:'', amt:1000.00, dt2:'2026-06-01'},
      {a:'100200', c:'ACME CORP', i:'5100000002', po:'PO-2', so:'', d:'', amt:2000.00, dt2:'2026-06-02'},
      {a:'100200', c:'ACME CORP', i:'5100000003', po:'PO-3', so:'', d:'', amt:1200.00, dt2:'2026-06-03'},
      {a:'100200', c:'ACME CORP', i:'5100000004', po:'PO-4', so:'', d:'', amt:1800.00, dt2:'2026-06-04'}
    ];
    PAY = [ {a:'100200', c:'ACME CORP', amt:3000.00, i:'', po:'', so:'', m:'ACH', txId:'TX-AMB-1', payDate:'06/20/2026', n:'lump payment no remit'} ];
    RES = []; EXC = [];
    _invalidateInvIndexes(); _buildInvIndexes();
  `);

  await w.runMatch();
  await h.waitFor(() => h.g(`EXC.length`) > 0 || h.g(`RES.length`) > 0, 8000);
  await sleep(300);

  // ── Engine routed the lump to an Ambiguous exception, not a guess ──
  const excType = h.g(`(EXC[0]||{}).type`);
  eq('engine creates Ambiguous exception (no auto-apply)', excType, 'Ambiguous');
  eq('no RES rows auto-applied for the ambiguous lump', h.g(`RES.length`), 0);
  const combos = h.g(`(EXC[0]||{}).ambigCombos||''`);
  check('EXC carries both candidate combos', /5100000001\+5100000002/.test(combos) && /5100000003\+5100000004/.test(combos), combos);
  check('EXC detail names the amount and choice', /invoice combinations tie to \$3,000\.00/.test(h.g(`(EXC[0]||{}).detail||''`)));

  // ── Chip rendering ──
  w.naUpdateChipCounts();
  eq('Ambiguous chip count shows 1', d.getElementById('na-ct-Ambiguous').textContent, '1');
  eq('All chip count shows 1', d.getElementById('na-ct-all').textContent, '1');
  const ambChip = d.querySelector('.na-chip[data-type="Ambiguous"]');
  check('Ambiguous chip exists with tooltip', !!ambChip && /chooses? the correct combination/i.test(ambChip.getAttribute('title') || ''));

  // Chip click activates it, syncs the type filter, re-renders EXC list
  w.naChipClick(ambChip);
  check('clicked chip becomes active', ambChip.classList.contains('na-chip-active'));
  eq('only one chip active', d.querySelectorAll('.na-chip.na-chip-active').length, 1);
  eq('exc-type-filter synced to Ambiguous', (d.getElementById('exc-type-filter') || {}).value, 'Ambiguous');

  // Resolution playbook for Ambiguous = Choose Combination
  const playbook = h.g(`(typeof EXC_PLAYBOOK!=='undefined'&&EXC_PLAYBOOK['Ambiguous'])?EXC_PLAYBOOK['Ambiguous'].label:(function(){try{return null;}catch(e){return null;}})()`);
  if (playbook !== null) eq('playbook label is Choose Combination', playbook, 'Choose Combination');

  // ── Choose-combination flow: resolveException routes to the allocation workspace ──
  w.resolveException(0, 'Apply to invoice');
  await sleep(450); // armpResolveAmbiguous defers 200ms

  check('workspace payment loaded (ENG_PAY set)', !!h.g(`typeof ENG_PAY!=='undefined'&&ENG_PAY`));
  eq('ENG_PAY is the ambiguous payment', h.g(`ENG_PAY.txId`), 'TX-AMB-1');
  eq('workspace remembers source exception', h.g(`ENG_PAY._fromAmbigExc`), 0);
  const candFlags = h.g(`ENG_ROWS.map(function(r){return !!r._candidate;})`);
  eq('all 4 candidate invoices pre-highlighted', candFlags.filter(Boolean).length, 4);
  eq('payment dropdown synced', (d.getElementById('eng-pay-sel') || {}).value, '0');

  // ── Specialist chooses the {1200, 1800} combination and approves ──
  h.g(`
    ENG_ROWS.forEach(function(r){
      if(r.inv.i==='5100000003'||r.inv.i==='5100000004'){ r.selected=true; r.applyAmt=r.inv.amt; }
    });
    engUpdateTotals();
  `);
  w.engApprove();
  await sleep(250);

  eq('exception marked Resolved on approval', h.g(`EXC[0].s`), 'Resolved');
  eq('exception decision recorded', h.g(`EXC[0].dec`), 'Applied to invoices');
  eq('two RES rows created from the chosen combo', h.g(`RES.filter(function(r){return r.fromAlloc;}).length`), 2);
  eq('RES invoices are the chosen combination', h.g(`RES.map(function(r){return r.i;}).sort()`), ['5100000003', '5100000004']);
  eq('both RES rows are Exact', h.g(`RES.every(function(r){return r.st==='Exact';})`), true);

  // Chip count decrements after resolution
  w.naUpdateChipCounts();
  eq('Ambiguous chip count back to 0 after resolve', d.getElementById('na-ct-Ambiguous').textContent, '0');
  eq('All chip count back to 0', d.getElementById('na-ct-all').textContent, '0');

  // No uncaught page errors during the whole flow
  eq('no uncaught page errors', h.errors, []);

  summary('T1 ambiguous-allocation-ui');
})().catch((e) => { console.error(e); process.exit(1); });
