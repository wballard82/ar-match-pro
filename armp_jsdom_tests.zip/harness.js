// ARMP jsdom test harness — boots app.html with SheetJS injected and a Pro login
const fs = require('fs');
const path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');
const XLSXlib = require('xlsx');

const APP = path.join(__dirname, '..', 'app.html');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function boot(opts = {}) {
  const html = fs.readFileSync(APP, 'utf8');
  const errors = [];
  const consoleWarnings = [];
  const vc = new VirtualConsole();
  vc.on('jsdomError', (e) => {
    const msg = String((e && e.message) || e);
    // External resources (cdnjs/stripe) can't load in the sandbox — not app bugs.
    if (/resource|Could not load|HTMLCanvasElement's getContext/i.test(msg)) return;
    errors.push(msg + (e && e.detail && e.detail.stack ? '\n' + e.detail.stack : ''));
  });
  vc.on('error', (...a) => consoleWarnings.push('[console.error] ' + a.map(String).join(' ')));
  vc.on('warn', (...a) => consoleWarnings.push('[console.warn] ' + a.map(String).join(' ')));

  const dom = new JSDOM(html, {
    url: 'https://app.armatchpro.test/app.html',
    runScripts: 'dangerously',
    pretendToBeVisual: true,
    virtualConsole: vc,
    beforeParse(window) {
      // CDN script can't load in sandbox; same lib+version injected locally.
      // Shim read(): jsdom ArrayBuffers are cross-realm, so SheetJS's
      // `instanceof ArrayBuffer` check fails and it would misread the zip as CSV.
      // A real browser is same-realm, so this only corrects the test environment.
      const XShim = Object.assign({}, XLSXlib);
      XShim.read = (data, readOpts) => {
        if (data && typeof data !== 'string' && typeof data.byteLength === 'number') {
          const u8 = data.buffer ? new Uint8Array(data.buffer, data.byteOffset || 0, data.byteLength)
                                 : new Uint8Array(data);
          return XLSXlib.read(Buffer.from(u8), Object.assign({}, readOpts, { type: 'buffer' }));
        }
        return XLSXlib.read(data, readOpts);
      };
      window.XLSX = XShim;
      // jsdom has no crypto.subtle; supply Node's real Web Crypto so the app's
      // PBKDF2 password hashing runs exactly as it would in a browser.
      try {
        const { webcrypto } = require('crypto');
        if (!window.crypto || !window.crypto.subtle) {
          Object.defineProperty(window, 'crypto', { value: webcrypto, configurable: true });
        }
        if (typeof window.TextEncoder === 'undefined') window.TextEncoder = TextEncoder;
        if (typeof window.TextDecoder === 'undefined') window.TextDecoder = TextDecoder;
      } catch (e) {}
      if (!window.matchMedia) {
        window.matchMedia = (q) => ({
          matches: false, media: q,
          addListener() {}, removeListener() {},
          addEventListener() {}, removeEventListener() {},
          dispatchEvent() { return false; }
        });
      }
      window.alert = () => {};
      window.confirm = () => true;
      window.prompt = () => '';
      window.scrollTo = () => {};
      window.HTMLElement.prototype.scrollIntoView = function () {};
      // Capture file downloads instead of navigating
      window.__downloads = [];
      window.URL.createObjectURL = (blob) => {
        const id = 'blob:armp/' + window.__downloads.length;
        window.__downloads.push({ id, blob });
        return id;
      };
      window.URL.revokeObjectURL = () => {};
      const origClick = window.HTMLAnchorElement.prototype.click;
      window.__anchorClicks = [];
      window.HTMLAnchorElement.prototype.click = function () {
        if (this.hasAttribute('download') || /^blob:/.test(this.href)) {
          window.__anchorClicks.push({ href: this.getAttribute('href'), download: this.getAttribute('download') });
          return; // swallow download navigation
        }
        return origClick.call(this);
      };
      if (opts.localStorage) {
        for (const [k, v] of Object.entries(opts.localStorage)) window.localStorage.setItem(k, v);
      }
    }
  });

  const window = dom.window;
  await new Promise((res) => {
    if (window.document.readyState === 'complete') res();
    else window.addEventListener('load', res);
  });
  await sleep(80);

  const h = {
    dom, window, errors, consoleWarnings,
    g: (code) => window.eval(code),          // read/write top-level `let` bindings in page scope
    sleep,
    async login(plan = 'pro') {
      h.g(`CURRENT_USER='qa@armp.test'; IS_DEMO=false;`);
      window.launchApp({ name: 'QA Tester', company: 'QA Co', plan, email: 'qa@armp.test' });
      await sleep(450); // launchApp defers session prompt / setup modal by 200ms
      // Close the setup modal if it opened, so it never intercepts anything
      try { const m = window.document.getElementById('armp-setup-overlay'); if (m) m.remove(); } catch (e) {}
      return h;
    },
    // Read the decoded text of the last captured download
    async lastDownloadText() {
      const d = window.__downloads[window.__downloads.length - 1];
      if (!d) return null;
      if (typeof d.blob.text === 'function') return await d.blob.text();
      return null;
    },
    async waitFor(fn, timeout = 8000, every = 50) {
      const t0 = Date.now();
      for (;;) {
        let v; try { v = fn(); } catch (e) { v = false; }
        if (v) return v;
        if (Date.now() - t0 > timeout) throw new Error('waitFor timed out');
        await sleep(every);
      }
    }
  };
  return h;
}

// ── Tiny assert kit ────────────────────────────────────────────────────────
let _pass = 0, _fail = 0;
const _failures = [];
function check(name, cond, extra) {
  if (cond) { _pass++; console.log('  ✓ ' + name); }
  else { _fail++; _failures.push(name); console.log('  ✗ ' + name + (extra !== undefined ? '  → got: ' + JSON.stringify(extra) : '')); }
}
function eq(name, actual, expected) {
  check(name, JSON.stringify(actual) === JSON.stringify(expected), actual);
}
function summary(suiteName) {
  console.log(`\n[${suiteName}] ${_pass} passed, ${_fail} failed`);
  if (_fail) { console.log('Failures:\n - ' + _failures.join('\n - ')); }
  process.exit(_fail ? 1 : 0); // app-side intervals (inactivity watch) would otherwise keep node alive
}

module.exports = { boot, sleep, check, eq, summary };
