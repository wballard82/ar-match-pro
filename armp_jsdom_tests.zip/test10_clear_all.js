// TEST 10 — Clear All must wipe EVERYTHING including the payment queue and the
// lingering expanded allocation card (ENG_PAY). This is the production complaint.
const { boot, sleep, check, eq, summary } = require('./harness');
const fs = require('fs');

(async () => {
  const h = await boot();
  await h.login('pro');
  const w = h.window, d = w.document;

  // Load a full working state: invoices, payments, matches, exceptions, ERS/VMI,
  // and an EXPANDED allocation card (the exact thing that lingered in production).
  w.openImport('inv');
  await sleep(50);
  w.setImportTextSafe(fs.readFileSync('/home/claude/verify/verify1_invoices_ambiguous.csv', 'utf8'));
  w.processImport();
  await h.waitFor(() => h.g('INV.length') === 4, 8000);

  w.openImportBank();
  await sleep(50);
  w.setImportTextSafe(fs.readFileSync('/home/claude/verify/verify1_payment_lump.csv', 'utf8'));
  w.processImport();
  await h.waitFor(() => h.g('PAY.length') === 1, 8000);

  // Expand the payment into the allocation workspace (sets ENG_PAY — the lingering card)
  w.engLoadPayment(0);
  await sleep(150);
  check('setup: payment expanded in workspace (ENG_PAY set)', !!h.g('ENG_PAY'));

  // Add some matches + exceptions + ERS/VMI so we prove they ALL clear
  h.g(`
    RES = [{a:'100200',c:'ACME CORP',i:'5100000001',oa:1000,pd:1000,vr:0,st:'Exact',m:'Direct invoice',fromAlloc:true,approved:true}];
    EXC = [{id:'EXC-001',a:'100200',c:'ACME CORP',amt:500,ref:'X',type:'Short pay',detail:'t',action:'r',dec:'',s:'Open'}];
    ERS_LINES = [{poNumber:'P1',amount:100,_type:'ERS'}];
    VMI_LINES = [{vcInvoice:'V1',amount:50,_type:'VMI'}];
    autoMatchHasRun = true;
    saveToStorage();
  `);
  w.renderPayQueue();
  await sleep(100);

  // Sanity: data present before clear
  eq('before clear: INV', h.g('INV.length'), 4);
  eq('before clear: PAY', h.g('PAY.length'), 1);
  eq('before clear: RES', h.g('RES.length'), 1);
  eq('before clear: EXC', h.g('EXC.length'), 1);
  check('before clear: payment queue shows 1', /\(1\)/.test((d.getElementById('pq-count') || {}).textContent || ''));
  check('before clear: localStorage has payments', !!w.localStorage.getItem(h.g("sk('pay')")));

  // ── THE CLEAR ── (call the core directly — the confirm dialog wraps it)
  w.armpClearEverythingCore();
  await sleep(200);

  // Every data array empty
  eq('after clear: INV empty', h.g('INV.length'), 0);
  eq('after clear: PAY empty (payment queue data)', h.g('PAY.length'), 0);
  eq('after clear: RES empty', h.g('RES.length'), 0);
  eq('after clear: EXC empty', h.g('EXC.length'), 0);
  eq('after clear: DELIV empty', h.g('DELIV.length'), 0);
  eq('after clear: ERS_LINES empty', h.g('ERS_LINES.length'), 0);
  eq('after clear: VMI_LINES empty', h.g('VMI_LINES.length'), 0);
  eq('after clear: autoMatchHasRun reset', h.g('autoMatchHasRun'), false);

  // The lingering expanded card is gone
  eq('after clear: ENG_PAY cleared (no lingering card)', h.g('ENG_PAY'), null);
  eq('after clear: ENG_ROWS cleared', h.g('ENG_ROWS.length'), 0);
  const engEmpty = d.getElementById('eng-empty');
  check('after clear: allocation workspace shows empty state', !engEmpty || engEmpty.style.display !== 'none');

  // Payment queue UI empty
  w.renderPayQueue();
  await sleep(50);
  check('after clear: payment queue count (0)', /\(0\)/.test((d.getElementById('pq-count') || {}).textContent || ''));
  check('after clear: payment queue shows "No payments"', /No payments/.test((d.getElementById('pq-list') || {}).innerHTML || ''));

  // Storage wiped
  check('after clear: localStorage payments removed', !w.localStorage.getItem(h.g("sk('pay')")));
  check('after clear: localStorage invoices removed', !w.localStorage.getItem(h.g("sk('inv')")));
  check('after clear: localStorage matches removed', !w.localStorage.getItem(h.g("sk('res')")));

  // Chip counts zeroed
  check('after clear: Ambiguous chip 0', (d.getElementById('ws-na-ct-Ambiguous') || {}).textContent === '0' || (d.getElementById('na-ct-Ambiguous') || {}).textContent === '0');

  eq('no uncaught page errors', h.errors, []);
  summary('T10 clear-all-full-wipe');
})().catch((e) => { console.error(e); process.exit(1); });
