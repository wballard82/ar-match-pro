// TEST 1b — Premium Needs Attention tab (the panel users actually see):
// chip strip present, counts, click-to-filter, Choose Combination suggested
// action, and the full choose-combination flow — via the REAL import path.
const { boot, sleep, check, eq, summary } = require('./harness');
const fs = require('fs');

(async () => {
  const h = await boot();
  await h.login('pro');
  const w = h.window, d = w.document;

  // Real UI flow: + Invoices → CSV → import
  w.openImport('inv');
  await sleep(150);
  w.setImportTextSafe(fs.readFileSync('/home/claude/verify/verify1_invoices_ambiguous.csv', 'utf8'));
  w.processImport();
  await h.waitFor(() => h.g('INV.length') === 4, 8000);

  // Real UI flow: + Bank File → CSV → import
  w.openImportBank();
  await sleep(200);
  w.setImportTextSafe(fs.readFileSync('/home/claude/verify/verify1_payment_lump.csv', 'utf8'));
  w.processImport();
  await h.waitFor(() => h.g('PAY.length') === 1, 8000);

  // Real UI flow: ⚡ Auto Match button
  await w.runMatch();
  await h.waitFor(() => h.g('EXC.length') > 0, 10000);
  await sleep(400);

  eq('import path: engine produces Ambiguous (not COA fall-through)', h.g('EXC[0].type'), 'Ambiguous');
  eq('import path: nothing auto-applied', h.g('RES.length'), 0);

  // Premium panel renders (this is Cash Application → Needs Attention)
  w.renderWsExcPremium();
  await sleep(150);

  const strip = d.getElementById('ws-na-chips');
  check('premium panel HAS the chip strip', !!strip);
  eq('premium strip has 9 chips', strip.querySelectorAll('.na-chip').length, 9);
  eq('premium Ambiguous chip count = 1', d.getElementById('ws-na-ct-Ambiguous').textContent, '1');
  eq('premium All chip count = 1', d.getElementById('ws-na-ct-all').textContent, '1');
  eq('premium header count text', d.getElementById('ws-exc-ct').textContent, '1 exception');

  // Chip click filters the premium list + syncs the premium dropdown
  const ambChip = strip.querySelector('.na-chip[data-type="Ambiguous"]');
  w.wsNaChipClick(ambChip);
  await sleep(100);
  check('clicked premium chip active', ambChip.classList.contains('na-chip-active'));
  eq('premium dropdown synced', d.getElementById('ws-exc-type-filter').value, 'Ambiguous');
  const listHtml = d.getElementById('ws-exc-list').innerHTML;
  check('filtered list shows the ambiguous card', /Ambiguous allocation/.test(listHtml));
  check('card SUGGESTED chip reads Choose Combination', /Choose Combination/.test(listHtml));

  // A non-matching chip filters to empty
  w.wsNaChipClick(strip.querySelector('.na-chip[data-type="Duplicate"]'));
  await sleep(100);
  check('non-matching chip → zero-exceptions empty state', /Zero exceptions/.test(d.getElementById('ws-exc-list').innerHTML));
  w.wsNaChipClick(strip.querySelector('.na-chip[data-type=""]')); // back to All
  await sleep(100);

  // Click the SUGGESTED "Choose Combination" chip → routes to allocation workspace
  w.resolveException(0, 'Apply to invoice'); // same call the suggested chip fires
  await sleep(450);
  eq('workspace loaded from premium card', h.g('ENG_PAY.txId'), 'TX-AMB-1');
  eq('candidates pre-highlighted', h.g('ENG_ROWS.filter(function(r){return r._candidate;}).length'), 4);

  // Choose the {1200,1800} combo and approve
  h.g(`
    ENG_ROWS.forEach(function(r){
      if(r.inv.i==='5100000003'||r.inv.i==='5100000004'){ r.selected=true; r.applyAmt=r.inv.amt; }
    });
    engUpdateTotals();
  `);
  w.engApprove();
  await sleep(300);
  eq('exception resolved', h.g('EXC[0].s'), 'Resolved');
  eq('chosen combo posted', h.g('RES.map(function(r){return r.i;}).sort()'), ['5100000003', '5100000004']);

  // Premium panel re-render reflects resolution
  w.renderWsExcPremium();
  await sleep(150);
  eq('premium Ambiguous chip back to 0', d.getElementById('ws-na-ct-Ambiguous').textContent, '0');
  eq('premium All chip back to 0', d.getElementById('ws-na-ct-all').textContent, '0');

  eq('no uncaught page errors', h.errors, []);
  summary('T1b premium-needs-attention-panel');
})().catch((e) => { console.error(e); process.exit(1); });
