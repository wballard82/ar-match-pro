#!/bin/bash
# ARMP jsdom suite runner — run all suites sequentially, report totals
cd "$(dirname "$0")"
TOTAL_P=0; TOTAL_F=0; FAILED_SUITES=""
for t in test1_ambiguous_ui.js test1b_premium_panel.js test2_import_parsers.js test3_persistence.js test4_ers_vmi.js test6_resolution.js test7_posting_export.js test8_fixes.js test9_overlay_blocking.js test10_clear_all.js test11_all_matching.js test12_security.js; do
  echo "── $t ──────────────────────────────"
  OUT=$(timeout 200 node "$t" 2>&1)
  RC=$?
  echo "$OUT" | grep -E "^\s+✗|passed, [0-9]+ failed"
  P=$(echo "$OUT" | grep -oE '[0-9]+ passed' | grep -oE '[0-9]+')
  F=$(echo "$OUT" | grep -oE '[0-9]+ failed' | grep -oE '[0-9]+')
  TOTAL_P=$((TOTAL_P + ${P:-0})); TOTAL_F=$((TOTAL_F + ${F:-0}))
  if [ "$RC" -ne 0 ] || [ "${F:-1}" -ne 0 ]; then FAILED_SUITES="$FAILED_SUITES $t"; fi
done
echo "════════════════════════════════════"
echo "TOTAL: $TOTAL_P passed, $TOTAL_F failed"
[ -n "$FAILED_SUITES" ] && echo "FAILED SUITES:$FAILED_SUITES" && exit 1
echo "ALL SUITES GREEN"
