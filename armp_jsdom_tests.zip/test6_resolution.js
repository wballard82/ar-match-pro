// TEST 6 — Manual resolution workspace: approving matches, resolving exceptions,
// and the reconciliation table (adjustments → Reconciled/Open badges).
const { boot, sleep, check, eq, summary } = require('./harness');

(async () => {
  const h = await boot();
  await h.login('pro');
  const w = h.window, d = w.document;

  // ── 6a. Allocation approval: engLoadPayment → select → engApprove ─────
  h.g(`
    INV = [
      {a:'100200', c:'ACME CORP', i:'5100000001', po:'PO-1', amt:1000.00, dt2:'2026-06-01'},
      {a:'100200', c:'ACME CORP', i:'5100000002', po:'PO-2', amt:2500.00, dt2:'2026-06-02'},
      {a:'100200', c:'ACME CORP', i:'5100000003', po:'PO-3', amt:800.00,  dt2:'2026-06-03'}
    ];
    PAY = [ {a:'100200', c:'ACME CORP', amt:3300.00, i:'', po:'', m:'ACH', txId:'TX-M1', payDate:'06/22/2026'} ];
    RES = [ {a:'100200', c:'ACME CORP', i:'5100000002', oa:2500, pd:2500, vr:0, st:'Amount match', m:'Amount match', n:''} ]; // engine pre-match, NOT user-approved
    EXC = [];
    _invalidateInvIndexes(); _buildInvIndexes();
  `);
  w.engLoadPayment(0);
  await sleep(250);
  check('workspace loads the payment', h.g(`ENG_PAY && ENG_PAY.txId==='TX-M1'`));
  eq('workspace lists all open invoices for the account', h.g('ENG_ROWS.length'), 3);

  // Select 2500 (full) + 800 (full) = 3300
  h.g(`
    ENG_ROWS.forEach(function(r){
      if(r.inv.i==='5100000002'||r.inv.i==='5100000003'){ r.selected=true; r.applyAmt=r.inv.amt; }
    });
    engUpdateTotals();
  `);
  w.engApprove();
  await sleep(250);

  eq('approval state set', h.g('ENG_STATE'), 'approved');
  eq('duplicate engine RES for same invoice removed on approval', h.g(`RES.filter(function(r){return r.i==='5100000002';}).length`), 1);
  eq('approved rows are fromAlloc+approved', h.g(`RES.filter(function(r){return r.fromAlloc&&r.approved;}).length`), 2);
  eq('approved rows Exact status', h.g(`RES.filter(function(r){return r.fromAlloc;}).every(function(r){return r.st==='Exact';})`), true);
  check('idempotent: re-approving does not duplicate', (() => { w.engApprove(); return h.g(`RES.filter(function(r){return r.i==='5100000002';}).length`) === 1; })());
  check('audit trail recorded approval', /Allocation approved/.test(h.g(`AuditManager.getRecords().map(function(a){return a.action||'';}).join('|')`)));

  // ── 6b. Exception decisions: Chase customer + Duplicate — reject ──────
  h.g(`
    EXC = [
      {id:'EXC-101', a:'100300', c:'GLOBEX LLC', amt:5400.00, ref:'TX-C1', type:'Unmatched', detail:'No invoice found', action:'Review', dec:'', s:'Open'},
      {id:'EXC-102', a:'100300', c:'GLOBEX LLC', amt:5400.00, ref:'TX-C2', type:'Duplicate', detail:'Same amt/date as TX-C1', action:'Review', dec:'', s:'Open'}
    ];
  `);
  const resBefore = h.g('RES.length');
  w.resolveException(0, 'Chase customer');
  await sleep(150);
  eq('Chase customer: EXC resolved', h.g('EXC[0].s'), 'Resolved');
  eq('Chase customer: decision recorded', h.g('EXC[0].dec'), 'Chase customer');
  const chaseRow = h.g(`RES[RES.length-1] && {m:RES[RES.length-1].m, st:RES[RES.length-1].st, fromExc:RES[RES.length-1].fromExc}`);
  check('Chase customer: RES audit row (Pending follow-up)', chaseRow && chaseRow.m === 'Chase customer' && chaseRow.st === 'Pending follow-up' && chaseRow.fromExc === true, chaseRow);

  w.resolveException(1, 'Duplicate — reject');
  await sleep(150);
  eq('Duplicate reject: EXC resolved', h.g('EXC[1].s'), 'Resolved');
  const dupRow = h.g(`RES[RES.length-1] && {m:RES[RES.length-1].m, st:RES[RES.length-1].st, rejected:RES[RES.length-1].rejected}`);
  check('Duplicate reject: rejected RES audit row', dupRow && dupRow.st === 'Rejected' && dupRow.rejected === true, dupRow);
  eq('two RES audit rows added by decisions', h.g('RES.length'), resBefore + 2);

  // Guard: blank / placeholder decisions do nothing
  h.g(`EXC.push({id:'EXC-103', a:'', c:'X', amt:1, ref:'', type:'Bank fee', detail:'', action:'', dec:'', s:'Open'});`);
  w.resolveException(2, '— Select —');
  eq('placeholder decision ignored', h.g('EXC[2].s'), 'Open');

  // ── 6c. Reconciliation table: variance + adjustments → status badges ──
  h.g(`
    PAY = [
      {a:'100200', c:'ACME CORP', amt:2500.00, i:'5100000002', txId:'TX-R1', payDate:'06/22/2026', m:'ACH'},
      {a:'100200', c:'ACME CORP', amt:975.00,  i:'5100000004', txId:'TX-R2', payDate:'06/23/2026', m:'ACH'}
    ];
    RES = [
      {a:'100200', c:'ACME CORP', i:'5100000002', po:'PO-2', oa:2500, pd:2500, vr:0,   st:'Exact', m:'Direct invoice', fromAlloc:true, approved:true},
      {a:'100200', c:'ACME CORP', i:'5100000004', po:'PO-4', oa:1000, pd:975,  vr:-25, st:'Exact', m:'Direct invoice', fromAlloc:true, approved:true}
    ];
  `);
  w.renderWsRecon();
  await sleep(150);
  let badges = Array.from(d.querySelectorAll('#recon-list .recon-status')).map((b) => b.textContent.trim());
  eq('recon renders one badge per matched row', badges.length, 2);
  eq('zero-variance row shows Reconciled', badges[0], 'Reconciled');
  eq('-25 variance row shows Open', badges[1], 'Open');
  check('summary shows 1 of 2 reconciled', /1<\/strong> of <strong[^>]*>2/.test((d.getElementById('recon-summary') || {}).innerHTML || ''));

  // Enter a $25 write-off against the variance row → row becomes Reconciled
  h.g(`RES[1].writeOff = 25;`);
  w.renderWsRecon();
  await sleep(150);
  badges = Array.from(d.querySelectorAll('#recon-list .recon-status')).map((b) => b.textContent.trim());
  eq('write-off offsets variance → Reconciled', badges[1], 'Reconciled');
  check('summary now 2 of 2 reconciled', /2<\/strong> of <strong[^>]*>2/.test((d.getElementById('recon-summary') || {}).innerHTML || ''));

  // Unmatched payment section: a payment with no RES row shows as unmatched
  h.g(`PAY.push({a:'100999', c:'HOOLI', amt:5000.00, i:'', txId:'TX-R3', payDate:'06/24/2026', m:'WIRE'});`);
  w.renderWsRecon();
  await sleep(150);
  check('unmatched payment surfaces in recon view', /HOOLI/.test((d.getElementById('recon-list') || {}).innerHTML || ''));

  eq('no uncaught page errors', h.errors, []);
  summary('T6 manual-resolution-workspace');
})().catch((e) => { console.error(e); process.exit(1); });
