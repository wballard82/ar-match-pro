// TEST 8 — Regression coverage for fixes made this session:
//   A. armpUpdateBanner step states (hasPay/hasInv/hasMatched ReferenceError)
//   B. applyCfoAccess defined + role gate toggles; saveUserRole completes
//   C. _clearDeliveryIndexNow survives IndexedDB unavailability, resets bridges
const { boot, sleep, check, eq, summary } = require('./harness');

(async () => {
  const h = await boot();
  await h.login('pro');
  const w = h.window, d = w.document;

  // ── A. Banner step states now update with data ────────────────────────
  const banner = d.getElementById('armp-banner');
  if (banner) banner.style.display = 'block';
  h.g(`PAY=[{a:'1',c:'X',amt:1,txId:'T'}]; INV=[]; RES=[];`);
  const warnsBefore = h.consoleWarnings.filter((x) => /armpUpdateBanner/.test(x)).length;
  w.armpUpdateBanner();
  const warnsAfter = h.consoleWarnings.filter((x) => /armpUpdateBanner/.test(x)).length;
  eq('A: armpUpdateBanner no longer warns (ReferenceError gone)', warnsAfter - warnsBefore, 0);
  const s1 = d.getElementById('armp-banner-step-1');
  const s2 = d.getElementById('armp-banner-step-2');
  if (s1 && s2) {
    eq('A: step 1 done once payments imported', s1.getAttribute('data-state'), 'done');
    eq('A: step 2 active (invoices pending)', s2.getAttribute('data-state'), 'active');
    h.g(`INV=[{a:'1',c:'X',i:'9',amt:1}];`);
    w.armpUpdateBanner();
    eq('A: step 2 done once invoices imported', s2.getAttribute('data-state'), 'done');
  } else {
    check('A: banner step elements present', false, 'banner steps not found in DOM');
  }

  // ── B. applyCfoAccess + role gate ─────────────────────────────────────
  eq('B: applyCfoAccess is defined', h.g(`typeof applyCfoAccess`), 'function');
  const gate = d.getElementById('cfo-role-gate');
  const wrap = d.getElementById('cfo-content-wrap');
  check('B: CFO gate scaffolding present', !!gate && !!wrap);

  h.g(`USER_ROLE='specialist';`);
  w.applyCfoAccess();
  eq('B: specialist sees the role gate', gate.style.display, 'block');
  eq('B: specialist content hidden', wrap.style.display, 'none');

  h.g(`USER_ROLE='manager';`);
  w.applyCfoAccess();
  eq('B: manager sees CFO content (matches gate copy)', gate.style.display, 'none');

  h.g(`USER_ROLE='controller';`);
  w.applyCfoAccess();
  eq('B: controller sees CFO content', gate.style.display, 'none');

  // saveUserRole now completes through toast + audit (no mid-function throw)
  const sel = d.getElementById('s-role');
  if (sel) {
    // ensure an assignable option is selected
    const opt = Array.from(sel.options).find((o) => o.value === 'manager' && !o.disabled) || sel.options[0];
    sel.value = opt.value;
    const auditBefore = h.g(`AuditManager.getRecords().length`);
    w.saveUserRole();
    await sleep(100);
    check('B: saveUserRole reaches its audit record', h.g(`AuditManager.getRecords().length`) > auditBefore);
  }

  // ── C. Start fresh with IndexedDB unavailable ─────────────────────────
  h.g(`
    INV=[{a:'1',c:'X',i:'9',amt:1}]; PAY=[{a:'1',c:'X',amt:1}]; DELIV=[{deliveryNo:'D1', salesOrder:'SO1', poNo:'P1', amount:1}];
    window._DELIV_BRIDGE = new Map([['D1',{}]]);
    window._TRK_BRIDGE = new Map([['T1',[{}]]]);
    window._SO_BRIDGE = new Map([['SO1',{}]]);
  `);
  let threw = false;
  try { await w._armpDoSessionStartFresh(); await sleep(200); } catch (e) { threw = true; }
  await sleep(200);
  eq('C: Start fresh no longer throws without IndexedDB', threw, false);
  eq('C: DELIV cleared', h.g('DELIV.length'), 0);
  eq('C: delivery bridge map reset', h.g('window._DELIV_BRIDGE.size'), 0);
  eq('C: tracking bridge map reset', h.g('window._TRK_BRIDGE.size'), 0);
  eq('C: SO bridge map reset', h.g('window._SO_BRIDGE.size'), 0);

  eq('no uncaught page errors', h.errors, []);
  summary('T8 session-fix-regressions');
})().catch((e) => { console.error(e); process.exit(1); });
