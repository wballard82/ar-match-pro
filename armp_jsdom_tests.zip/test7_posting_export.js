// TEST 7 — Posting/export: ERP export profiles produce correct output,
// role gate enforced, posting file downloaded, status badges behave.
const { boot, sleep, check, eq, summary } = require('./harness');

(async () => {
  const h = await boot();
  await h.login('pro');
  const w = h.window, d = w.document;

  // Seed approved results (one clean, one partial from allocation)
  h.g(`
    INV = [
      {a:'100200', c:'ACME CORP', i:'5100000001', po:'PO-1', so:'SO-1', amt:1000.00, dt2:'2026-06-01'},
      {a:'100200', c:'ACME CORP', i:'5100000002', po:'PO-2', so:'SO-2', amt:2500.00, dt2:'2026-06-02'}
    ];
    PAY = [ {a:'100200', c:'ACME CORP', amt:3450.00, txId:'TX-E1', payDate:'06/25/2026', m:'WIRE'} ];
    RES = [
      {a:'100200', c:'ACME CORP', i:'5100000001', po:'PO-1', so:'SO-1', d:'TX-E1', oa:1000, pd:1000, vr:0,  st:'Exact',   m:'Cash Application', rdate:'2026-06-25', fromAlloc:true, approved:true},
      {a:'100200', c:'ACME CORP', i:'5100000002', po:'PO-2', so:'SO-2', d:'TX-E1', oa:2500, pd:2450, vr:-50, st:'Partial', m:'Cash Application', rdate:'2026-06-25', fromAlloc:true, approved:true, writeOff:50},
      {a:'', c:'', i:'', oa:99, pd:0, vr:0, st:'Pending follow-up', m:'Chase customer', dec:'Chase customer', fromExc:true, approved:true}
    ];
    EXC = [];
  `);

  // ── 7a. armpBuildExport per profile ───────────────────────────────────
  const rows = h.g(`armpExportableRows()`);
  // NEW-5: Chase-customer rows lacking account AND customer are excluded here
  // (exportPost's own filter re-admits them) — so 2, not 3.
  eq('exportable rows: approved rows in, blank chase row excluded', rows.length, 2);

  // Generic CSV profile
  const csvOut = h.g(`armpBuildExport(armpExportableRows().slice(0,2), 'csv')`);
  const csvLines = csvOut.content.split('\n');
  eq('CSV profile: header row', csvLines[0], 'Posting Date,Customer Account,Customer,Invoice,PO,Payment Amount,Variance,Write-off,Bank Fee,Status');
  check('CSV profile: row 1 values', csvLines[1] === '2026-06-25,100200,ACME CORP,5100000001,PO-1,1000.00,0.00,0.00,0.00,Exact', csvLines[1]);
  check('CSV profile: row 2 write-off + variance formatted', csvLines[2] === '2026-06-25,100200,ACME CORP,5100000002,PO-2,2450.00,-50.00,50.00,0.00,Partial', csvLines[2]);
  check('CSV profile: dated filename', /generic_csv.*_\d{8}\.csv/.test(csvOut.filename), csvOut.filename);

  // SAP F-28 profile — pipe-delimited, YYYYMMDD dates, constants
  const sapOut = h.g(`armpBuildExport(armpExportableRows().slice(0,1), 'sap')`);
  const sapLines = sapOut.content.split('\n');
  eq('SAP profile: pipe-delimited header', sapLines[0], 'COMPANY_CODE|DOC_DATE|POSTING_DATE|CUSTOMER_NO|REFERENCE|PO_REF|AMOUNT|CURRENCY|PAYMENT_METHOD');
  check('SAP profile: constants + YYYYMMDD + amount', sapLines[1] === 'US01|20260625|20260625|100200|5100000001|PO-1|1000.00|USD|WIRE', sapLines[1]);
  check('SAP profile: filename from profile name', /sap_f_28_import_\d{8}\.csv/.test(sapOut.filename), sapOut.filename);

  // NetSuite profile
  const nsOut = h.g(`armpBuildExport(armpExportableRows().slice(0,1), 'netsuite')`);
  const nsLines = nsOut.content.split('\n');
  eq('NetSuite profile: header', nsLines[0], 'External ID,Customer,Customer Name,Applied Date,Payment,Memo,Currency');
  check('NetSuite profile: row values', nsLines[1] === '5100000001,100200,ACME CORP,2026-06-25,1000.00,PO-1,USD', nsLines[1]);

  // Dynamics profile
  const dynOut = h.g(`armpBuildExport(armpExportableRows().slice(0,1), 'dynamics')`);
  check('Dynamics profile: header + row', dynOut.content.split('\n')[0] === 'CustAccount,CustomerName,TransactionDate,PaymentReference,PurchaseOrder,AmountCur,CurrencyCode'
    && dynOut.content.split('\n')[1] === '100200,ACME CORP,2026-06-25,5100000001,PO-1,1000.00,USD', dynOut.content.split('\n')[1]);

  // CSV quoting: value containing the delimiter gets quoted
  const qOut = h.g(`armpBuildExport([{rdate:'2026-06-25', a:'100200', c:'ACME, INC.', i:'X', po:'', pd:1, vr:0, st:'Exact'}], 'csv')`);
  check('CSV quoting: comma-containing customer quoted', qOut.content.split('\n')[1].indexOf('"ACME, INC."') >= 0, qOut.content.split('\n')[1]);

  // Unknown profile falls back to csv
  const fbOut = h.g(`armpBuildExport(armpExportableRows().slice(0,1), 'no_such_profile')`);
  check('unknown profile falls back to Generic CSV', /Posting Date,Customer Account/.test(fbOut.content));

  // ── 7b. Role gate on posting export ───────────────────────────────────
  h.g(`USER_ROLE='specialist';`);
  const dlBefore = w.__anchorClicks.length;
  w.exportPost();
  await sleep(150);
  eq('specialist role: posting export blocked (no download)', w.__anchorClicks.length, dlBefore);

  h.g(`USER_ROLE='manager';`);
  w.exportPost();
  await sleep(200);
  eq('manager role: posting file downloaded', w.__anchorClicks.length, dlBefore + 1);
  const dl = w.__anchorClicks[w.__anchorClicks.length - 1];
  check('posting filename dated', /posting_\d{4}-\d{2}-\d{2}\.csv/.test(dl.download), dl.download);
  // csvDL emits a data: URI with every cell quoted
  const postCsv = decodeURIComponent(dl.href.replace(/^data:text\/csv;charset=utf-8,/, ''));
  check('posting file header', postCsv.split('\n')[0] === '"Account","Customer","Payment Date","Invoice","PO","Sales Order","Delivery","Bridge Reason","Type","Document","Post Amount","Write-off","Bank Fee"', postCsv.split('\n')[0]);
  check('posting file includes both invoices with amounts', /5100000001/.test(postCsv) && /5100000002/.test(postCsv) && /"2450\.00"/.test(postCsv));
  check('posting file includes write-off column value', /"50\.00"/.test(postCsv));
  check('posting file includes the chase-customer audit row', postCsv.split('\n').length === 4, postCsv.split('\n').length);
  eq('rows flagged exported after posting', h.g(`RES.filter(function(r){return r.exported;}).length`), 3);

  // ── 7c. Review-tab status badges (Exported / Ready / Requires Review) ─
  h.g(`
    RES.push({a:'100200', c:'ACME CORP', i:'5100000009', oa:100, pd:90, vr:-10, st:'Partial', m:'PO group', n:''}); // unapproved engine partial → Requires Review
  `);
  w.rPost();
  await sleep(200);
  const postHtml = (d.getElementById('post-tb') || { innerHTML: '' }).innerHTML || d.body.innerHTML;
  check('badge: Exported shown for exported rows', /Exported/.test(postHtml));
  check('badge: Requires Review shown for unapproved engine match', /Requires Review/.test(postHtml));

  // Fresh (unexported) approved row shows Ready to Export
  h.g(`RES.push({a:'100200', c:'ACME CORP', i:'5100000010', po:'PO-Z', oa:70, pd:70, vr:0, st:'Exact', m:'Cash Application', rdate:'2026-06-26', fromAlloc:true, approved:true});`);
  w.rPost();
  await sleep(200);
  const postHtml2 = (d.getElementById('post-tb') || { innerHTML: '' }).innerHTML || d.body.innerHTML;
  check('badge: Ready to Export for fresh approved row', /Ready to Export/.test(postHtml2));

  // ── 7d. Export blockers guard (exportPostAndLock) ─────────────────────
  h.g(`EXC=[{id:'EXC-900', a:'100200', c:'ACME CORP', amt:10, ref:'', type:'Short pay', detail:'', action:'', dec:'', s:'Open'}];`);
  const blockers = h.g(`armpComputeExportBlockers()`);
  check('open exception counts as export blocker', blockers.blocked === true && blockers.reasons.join('|').indexOf('Needs Attention') >= 0, blockers);
  h.g(`EXC=[]; RES = RES.filter(function(r){ return !(r.i==='5100000009'); });`); // clear open EXC + unapproved engine match
  const blockers2 = h.g(`armpComputeExportBlockers()`);
  check('no blockers when exceptions resolved + matches approved', blockers2.blocked === false, blockers2);

  eq('no uncaught page errors', h.errors, []);
  summary('T7 posting-export');
})().catch((e) => { console.error(e); process.exit(1); });
