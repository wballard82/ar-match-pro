// TEST 4 — ERS/VMI end-to-end: real XML Spreadsheet 2003 files fed through the
// actual upload path (handleFile → _isXMLSpreadsheet → handleXMLSpreadsheet),
// then runMatch() exercising the Priority-5c remittance tie-out gate.
const { boot, sleep, check, eq, summary } = require('./harness');

const SS_NS = 'urn:schemas-microsoft-com:office:spreadsheet';

function xmlSheet(name, headers, rows) {
  const cell = (v) => `<Cell><Data ss:Type="${typeof v === 'number' ? 'Number' : 'String'}">${v}</Data></Cell>`;
  const row = (vals) => `<Row>${vals.map(cell).join('')}</Row>`;
  return `<Worksheet ss:Name="${name}"><Table>${row(headers)}${rows.map(row).join('')}</Table></Worksheet>`;
}
function xmlWorkbook(sheets) {
  return `<?xml version="1.0"?>\n<Workbook xmlns="${SS_NS}" xmlns:ss="${SS_NS}">${sheets.join('')}</Workbook>`;
}

(async () => {
  const h = await boot();
  await h.login('pro');
  const w = h.window;

  // ── Build a realistic ERS self-billing file ──────────────────────────
  // PO 4521000001: two lines (5,000 + 7,000 = 12,000) · PO 4521000002: one line (3,000)
  const ersHeaders = ['Delivery Date', 'Delivery Note', 'PO Number', 'PO Line Item', 'Description', 'Quantity', 'UOM', 'Price', 'Amount', 'Currency', 'Invoice Referencing Number'];
  const ersXml = xmlWorkbook([
    xmlSheet('06.15.2026', ersHeaders, [
      ['06/10/2026', 'DN-80001', '4521000001', '10', 'WIDGET A', 100, 'EA', 50, 5000, 'USD', 'ERS-INV-1'],
      ['06/11/2026', 'DN-80002', '4521000001', '20', 'WIDGET B', 70, 'EA', 100, 7000, 'USD', 'ERS-INV-1'],
      ['06/12/2026', 'DN-80003', '4521000002', '10', 'WIDGET C', 30, 'EA', 100, 3000, 'USD', 'ERS-INV-2']
    ])
  ]);
  const ersFile = new w.File([ersXml], 'ERS_SelfBilling_June.xls', { type: 'application/vnd.ms-excel' });

  // ── 4a. Parse via the real upload path ───────────────────────────────
  h.g(`IMP_TYPE='rem'; ERS_LINES=[]; VMI_LINES=[];`);
  await w.handleFile({ files: [ersFile], value: '' });
  await h.waitFor(() => h.g('ERS_LINES.length') === 3, 8000);

  eq('ERS upload: 3 lines parsed from real .xls file', h.g('ERS_LINES.length'), 3);
  eq('ERS upload: line type tagged', h.g('ERS_LINES[0]._type'), 'ERS');
  eq('ERS upload: PO numbers captured', h.g(`ERS_LINES.map(function(l){return l.poNumber;})`), ['4521000001', '4521000001', '4521000002']);
  eq('ERS upload: amounts captured', h.g(`ERS_LINES.map(function(l){return l.amount;})`), [5000, 7000, 3000]);
  eq('ERS upload: delivery notes captured', h.g('ERS_LINES[0].deliveryNote'), 'DN-80001');
  eq('ERS upload: invoice refs captured', h.g('ERS_LINES[2].invoiceRef'), 'ERS-INV-2');
  const poGroups = h.g(`ERSParser.groupByPO(ERS_LINES).map(function(g){return {po:g.poNumber, total:g.total, n:g.lines.length};})`);
  eq('ERS grouping: PO group totals', poGroups, [{ po: '4521000001', total: 12000, n: 2 }, { po: '4521000002', total: 3000, n: 1 }]);

  // ── 4b. Priority 5c — exact remittance tie-out ($232K-style case) ────
  // ERS total 15,000 == payment. Payment account/name deliberately does NOT
  // link to the aging rows, so priorities 1–7 all pass and only the ERS PO
  // tie-out (5c) can allocate.
  h.g(`
    INV = [
      {a:'100500', c:'CEL AMER', i:'5105000001', po:'4521000001', so:'', d:'RV', amt:12000.00, dt2:'2026-06-01'},
      {a:'100500', c:'CEL AMER', i:'5105000002', po:'4521000002', so:'', d:'RV', amt:3000.00, dt2:'2026-06-03'},
      {a:'100500', c:'CEL AMER', i:'5105000003', po:'4521999999', so:'', d:'RV', amt:999.99, dt2:'2026-06-05'}
    ];
    PAY = [ {a:'999999', c:'CELESTICA TEST HOLDINGS', amt:15000.00, i:'', po:'', so:'', m:'WIRE', txId:'TX-ERS-1', payDate:'06/20/2026', n:''} ];
    RES=[]; EXC=[];
    _invalidateInvIndexes(); _buildInvIndexes();
  `);
  await w.runMatch();
  await h.waitFor(() => h.g('RES.length') >= 2, 10000);
  await sleep(300);

  eq('5c exact tie: 2 invoices allocated via ERS groups', h.g(`RES.filter(function(r){return r.scenario==='ERS_GROUP';}).length`), 2);
  eq('5c exact tie: allocated invoices', h.g(`RES.map(function(r){return r.i;}).sort()`), ['5105000001', '5105000002']);
  eq('5c exact tie: both Exact', h.g(`RES.every(function(r){return r.st==='Exact';})`), true);
  eq('5c exact tie: fromAlloc set (export-eligible)', h.g(`RES.every(function(r){return r.fromAlloc===true;})`), true);
  check('5c exact tie: match reason names remittance tie-out', /Remittance tie-out|ERS/.test(h.g('RES[0].m') + h.g('RES[0].n')));
  check('5c exact tie: confidence attached', h.g('RES[0].confidence') > 0, h.g('RES[0].confidence'));
  eq('5c exact tie: unrelated invoice untouched', h.g(`(INV.find(function(v){return v.i==='5105000003';})||{}).s||null`), null);
  eq('5c exact tie: no variance exceptions', h.g(`EXC.length`), 0);

  // ── 4c. Priority 5c — short-pay variance ($686K-style case) ──────────
  // Same ERS file, payment 14,800: PO-1 group (12,000) allocates; PO-2 group
  // (3,000) exceeds the payment cap → routes to per-line COA; the remaining
  // −200 posts as a Short pay deduction EXC.
  h.g(`
    INV = [
      {a:'100500', c:'CEL AMER', i:'5105000001', po:'4521000001', so:'', d:'RV', amt:12000.00, dt2:'2026-06-01'},
      {a:'100500', c:'CEL AMER', i:'5105000002', po:'4521000002', so:'', d:'RV', amt:3000.00, dt2:'2026-06-03'}
    ];
    PAY = [ {a:'999999', c:'CELESTICA TEST HOLDINGS', amt:14800.00, i:'', po:'', so:'', m:'WIRE', txId:'TX-ERS-2', payDate:'06/21/2026', n:''} ];
    RES=[]; EXC=[];
    _invalidateInvIndexes(); _buildInvIndexes();
  `);
  await w.runMatch();
  await h.waitFor(() => h.g('RES.length') >= 1, 10000);
  await sleep(300);

  eq('5c short-pay: PO-1 invoice allocated', h.g(`RES.filter(function(r){return r.i==='5105000001'&&r.st==='Exact';}).length`), 1);
  eq('5c short-pay: PO-2 invoice NOT force-applied', h.g(`RES.filter(function(r){return r.i==='5105000002';}).length`), 0);
  const coaExc = h.g(`EXC.filter(function(e){return e.type==='Cash on Account';}).map(function(e){return {amt:e.amt, po:e.po, notes:e.notes, conf:e.confidence};})`);
  eq('5c short-pay: unmatched ERS group routes to per-line COA', coaExc.length, 1);
  check('5c short-pay: COA line carries PO + amount context', coaExc[0] && coaExc[0].amt === 3000 && coaExc[0].po === '4521000002' && /COA for PO 4521000002/.test(coaExc[0].notes), coaExc[0]);
  eq('5c short-pay: ERS residual COA confidence 96', coaExc[0] && coaExc[0].conf, 96);
  const spExc = h.g(`EXC.filter(function(e){return e.type==='Short pay';}).map(function(e){return e.amt;})`);
  eq('5c short-pay: $200 deduction EXC posted', spExc, [200]);

  // ── 4d. VMI file through the same real upload path ───────────────────
  const vmiHeaders = ['Vendor', 'Date', 'VC Invoice', 'Purchase Order', 'Item', 'Child Material Document', 'Part No', 'Quantity', 'UOM', 'Unit Price', 'Total Amount', 'Currency'];
  const vmiXml = xmlWorkbook([
    xmlSheet('VC Detail', vmiHeaders, [
      ['CEL AMER', '06/15/2026', 'VC-90001', 'VC;;06/15/2026', '10', 'MD-1', 'P-100', 10, 'EA', 120, 1200, 'USD'],
      ['CEL AMER', '06/16/2026', 'VC-90001', 'VC;;06/16/2026', '20', 'MD-2', 'P-101', 5, 'EA', 160, 800, 'USD'],
      ['CEL AMER', '06/17/2026', 'VC-90002', 'VC;;06/17/2026', '10', 'MD-3', 'P-102', 2, 'EA', 500, 1000, 'USD']
    ])
  ]);
  const vmiFile = new w.File([vmiXml], 'VMI_Consignment_June.xls', { type: 'application/vnd.ms-excel' });
  h.g(`VMI_LINES=[];`);
  await w.handleFile({ files: [vmiFile], value: '' });
  await h.waitFor(() => h.g('VMI_LINES.length') === 3, 8000);

  eq('VMI upload: 3 lines parsed', h.g('VMI_LINES.length'), 3);
  eq('VMI upload: type tagged', h.g('VMI_LINES[0]._type'), 'VMI');
  eq('VMI upload: amounts from Total Amount column', h.g(`VMI_LINES.map(function(l){return l.amount;})`), [1200, 800, 1000]);
  eq('VMI upload: VC invoice refs', h.g(`VMI_LINES.map(function(l){return l.vcInvoice;})`), ['VC-90001', 'VC-90001', 'VC-90002']);
  const vmiGroups = h.g(`VMIParser.groupByVCInvoice(VMI_LINES).map(function(g){return {vc:g.vcInvoice, total:g.total};})`);
  eq('VMI grouping by VC invoice', vmiGroups, [{ vc: 'VC-90001', total: 2000 }, { vc: 'VC-90002', total: 1000 }]);
  eq('VMI upload: material documents captured', h.g('VMI_LINES[0].materialDoc'), 'MD-1');

  eq('no uncaught page errors', h.errors, []);
  summary('T4 ers-vmi-end-to-end');
})().catch((e) => { console.error(e); process.exit(1); });
