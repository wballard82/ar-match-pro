// TEST 3 — Persistence: data survives a "refresh" + the Welcome back session prompt
// Simulates refresh by booting a second JSDOM seeded with the first one's localStorage.
const { boot, sleep, check, eq, summary } = require('./harness');

(async () => {
  // ── Session A: import data, save, snapshot localStorage ──────────────
  const a = await boot();
  await a.login('pro');
  a.g(`
    INV = [
      {a:'100200', c:'ACME CORP', i:'5100000001', po:'PO-1', amt:1000.00, dt2:'2026-06-01'},
      {a:'100200', c:'ACME CORP', i:'5100000002', po:'PO-2', amt:2000.00, dt2:'2026-06-02'},
      {a:'100300', c:'GLOBEX LLC', i:'5100000003', po:'PO-3', amt:500.00, dt2:'2026-06-03'}
    ];
    PAY = [ {a:'100200', c:'ACME CORP', amt:1000.00, i:'5100000001', txId:'TX-1', payDate:'06/20/2026', m:'ACH'} ];
    RES = [ {a:'100200', c:'ACME CORP', i:'5100000001', oa:1000, pd:1000, vr:0, st:'Exact', m:'Direct invoice', fromAlloc:true, approved:true} ];
    EXC = [ {id:'EXC-001', a:'100300', c:'GLOBEX LLC', amt:75.00, ref:'—', type:'Bank fee', detail:'t', action:'Review', dec:'', s:'Open'} ];
    saveToStorage();
  `);
  const savedKeys = {};
  for (let i = 0; i < a.window.localStorage.length; i++) {
    const k = a.window.localStorage.key(i);
    savedKeys[k] = a.window.localStorage.getItem(k);
  }
  check('session A wrote user-scoped keys', !!savedKeys['armp_qa@armp.test_inv'] && !!savedKeys['armp_qa@armp.test_saved_at'], Object.keys(savedKeys).filter(k=>/^armp_qa/.test(k)));
  a.window.close();

  // ── Session B: fresh boot ("refresh"), same localStorage, same user ──
  const b = await boot({ localStorage: savedKeys });
  await b.login('pro');   // launchApp → loadFromStorage → session prompt after 200ms
  await sleep(300);
  const d = b.window.document;

  eq('after refresh: 3 invoices restored', b.g('INV.length'), 3);
  eq('after refresh: payment restored', b.g('PAY.length'), 1);
  eq('after refresh: RES restored', b.g('RES.length'), 1);
  eq('after refresh: EXC restored', b.g('EXC.length'), 1);
  eq('after refresh: restored invoice amounts intact', b.g(`INV.map(function(v){return v.amt;})`), [1000, 2000, 500]);
  eq('after refresh: autoMatchHasRun re-derived from RES', b.g('autoMatchHasRun'), true);

  // ── Welcome back prompt ──
  const overlay = d.getElementById('armp-session-overlay');
  check('Welcome back overlay shown', !!overlay);
  const otext = overlay ? overlay.textContent : '';
  check('prompt says "Welcome back"', /Welcome back/.test(otext));
  check('prompt shows invoice count + customers', /3.*open invoices/.test(otext.replace(/\s+/g, ' ')) && /2.*customers/.test(otext.replace(/\s+/g, ' ')), otext.slice(0, 220));
  check('prompt shows payment count', /1.*payment/.test(otext.replace(/\s+/g, ' ')));
  check('prompt shows freshness ("moments ago")', /moments ago|minute/.test(otext));
  check('prompt offers Continue + Start fresh', /Continue working/.test(otext) && /Start fresh/.test(otext));

  // Continue → overlay dismissed, data untouched
  b.window.armpSessionContinue();
  await sleep(150);
  check('overlay removed after Continue', !d.getElementById('armp-session-overlay'));
  eq('data intact after Continue', b.g('INV.length'), 3);
  b.window.close();

  // ── Session C: Start fresh path wipes data + storage ─────────────────
  const c = await boot({ localStorage: savedKeys });
  await c.login('pro');
  await sleep(300);
  check('C: prompt shown again', !!c.window.document.getElementById('armp-session-overlay'));
  c.window._armpDoSessionStartFresh(); // the confirmed action behind Start fresh
  await sleep(150);
  eq('C: INV wiped', c.g('INV.length'), 0);
  eq('C: PAY wiped', c.g('PAY.length'), 0);
  check('C: user-scoped storage keys removed', !c.window.localStorage.getItem('armp_qa@armp.test_inv'));
  c.window.close();

  // ── Session D: weekly fresh start — stale saved_at (pre-Monday) auto-clears, no prompt ──
  const staleKeys = Object.assign({}, savedKeys);
  staleKeys['armp_qa@armp.test_saved_at'] = String(Date.now() - 9 * 24 * 3600 * 1000); // 9 days ago
  const dS = await boot({ localStorage: staleKeys });
  await dS.login('pro');
  await sleep(350);
  check('D: stale session shows NO restore prompt', !dS.window.document.getElementById('armp-session-overlay'));
  eq('D: stale data auto-cleared (weekly fresh start)', dS.g('INV.length'), 0);
  check('D: stale storage keys removed', !dS.window.localStorage.getItem('armp_qa@armp.test_inv'));

  // ── Demo isolation: demo login must NOT restore or prompt ────────────
  const e = await boot({ localStorage: savedKeys });
  e.g(`CURRENT_USER='qa@armp.test'; IS_DEMO=true;`);
  e.window.launchApp({ name: 'QA', plan: 'demo', email: 'qa@armp.test' });
  await sleep(400);
  check('demo: no restore prompt', !e.window.document.getElementById('armp-session-overlay'));
  eq('demo: workspace starts empty', e.g('INV.length'), 0);

  eq('no uncaught page errors', b.errors.concat(c.errors, dS.errors, e.errors), []);
  summary('T3 persistence-welcome-back');
})().catch((err) => { console.error(err); process.exit(1); });
