// TEST 11 — Every matching scenario, end to end through runMatch(), real data.
// Each scenario resets INV/PAY, runs the real engine, asserts the outcome.
const { boot, sleep, check, eq, summary } = require('./harness');

(async () => {
  const h = await boot();
  await h.login('pro');
  const w = h.window;

  async function scenario(name, setup, assertFn) {
    h.g(`INV=[];PAY=[];RES=[];EXC=[];DELIV=[];ERS_LINES=[];VMI_LINES=[];REM_DETAIL=[];
         window._DELIV_BRIDGE=new Map();window._TRK_BRIDGE=new Map();window._SO_BRIDGE=new Map();
         _invalidateInvIndexes();`);
    setup();
    h.g(`_invalidateInvIndexes(); _buildInvIndexes();`);
    await w.runMatch();
    await sleep(250);
    assertFn();
  }

  // ── P1: Exact invoice # match, exact amount ──
  await scenario('exact invoice', () => {
    h.g(`INV=[{a:'100',c:'ACME',i:'INV001',po:'',so:'',amt:1000,dt2:'2026-06-01'}];
         PAY=[{a:'100',c:'ACME',i:'INV001',amt:1000,txId:'T1',payDate:'06/20/2026'}];`);
  }, () => {
    eq('P1 exact invoice: matched Exact', h.g(`(RES[0]||{}).st`), 'Exact');
    eq('P1 exact invoice: method Direct invoice', h.g(`(RES[0]||{}).m`), 'Direct invoice');
    eq('P1 exact invoice: no exception', h.g('EXC.length'), 0);
  });

  // ── P1 variance: invoice match, short pay ──
  await scenario('invoice short pay', () => {
    h.g(`INV=[{a:'100',c:'ACME',i:'INV002',amt:1000,dt2:'2026-06-01'}];
         PAY=[{a:'100',c:'ACME',i:'INV002',amt:900,txId:'T2',payDate:'06/20/2026'}];`);
  }, () => {
    eq('P1 short pay: RES status Short pay', h.g(`(RES[0]||{}).st`), 'Short pay');
    eq('P1 short pay: exception raised', h.g(`(EXC[0]||{}).type`), 'Short pay');
    eq('P1 short pay: variance -100', h.g(`(RES[0]||{}).vr`), -100);
  });

  // ── P1 variance: invoice match, overpay ──
  await scenario('invoice overpay', () => {
    h.g(`INV=[{a:'100',c:'ACME',i:'INV003',amt:1000,dt2:'2026-06-01'}];
         PAY=[{a:'100',c:'ACME',i:'INV003',amt:1100,txId:'T3',payDate:'06/20/2026'}];`);
  }, () => {
    eq('P1 overpay: RES status Overpay', h.g(`(RES[0]||{}).st`), 'Overpay');
    eq('P1 overpay: exception Overpay', h.g(`(EXC[0]||{}).type`), 'Overpay');
  });

  // ── P3: PO group match (multiple invoices same PO summing to payment) ──
  await scenario('PO group', () => {
    h.g(`INV=[{a:'100',c:'ACME',i:'I1',po:'PO500',amt:600,dt2:'2026-06-01'},
              {a:'100',c:'ACME',i:'I2',po:'PO500',amt:400,dt2:'2026-06-02'}];
         PAY=[{a:'100',c:'ACME',i:'',po:'PO500',amt:1000,txId:'T4',payDate:'06/20/2026'}];`);
  }, () => {
    eq('P3 PO group: 2 invoices matched', h.g(`RES.length`), 2);
    check('P3 PO group: both settled', h.g(`RES.every(function(r){return r.st==='Exact'||r.st==='Subset exact';})`), h.g('RES.map(function(r){return r.st;})'));
  });

  // ── P6: Customer account + amount (no invoice ref) ──
  await scenario('account + amount', () => {
    h.g(`INV=[{a:'200',c:'GLOBEX',i:'G1',po:'',amt:2500,dt2:'2026-06-01'}];
         PAY=[{a:'200',c:'GLOBEX',i:'',po:'',amt:2500,txId:'T5',payDate:'06/20/2026'}];`);
  }, () => {
    eq('P6 account+amount: matched', h.g(`(RES[0]||{}).st`), 'Amount match');
  });

  // ── P7 multi-invoice subset-sum (unique) ──
  await scenario('subset-sum unique', () => {
    h.g(`INV=[{a:'300',c:'INITECH',i:'N1',amt:700,dt2:'2026-06-01'},
              {a:'300',c:'INITECH',i:'N2',amt:300,dt2:'2026-06-02'},
              {a:'300',c:'INITECH',i:'N3',amt:9999,dt2:'2026-06-03'}];
         PAY=[{a:'300',c:'INITECH',i:'',amt:1000,txId:'T6',payDate:'06/20/2026'}];`);
  }, () => {
    check('P7 subset-sum: 2 invoices auto-applied', h.g(`RES.filter(function(r){return r.i==='N1'||r.i==='N2';}).length`) === 2, h.g('RES.map(function(r){return r.i;})'));
    eq('P7 subset-sum: unrelated invoice untouched', h.g(`(INV.find(function(v){return v.i==='N3';})||{}).s||''`), '');
  });

  // ── Ambiguous: 2+ combos tie → no guess, Ambiguous exception ──
  await scenario('ambiguous', () => {
    h.g(`INV=[{a:'400',c:'ACME',i:'A1',amt:1000,dt2:'2026-06-01'},
              {a:'400',c:'ACME',i:'A2',amt:2000,dt2:'2026-06-02'},
              {a:'400',c:'ACME',i:'A3',amt:1200,dt2:'2026-06-03'},
              {a:'400',c:'ACME',i:'A4',amt:1800,dt2:'2026-06-04'}];
         PAY=[{a:'400',c:'ACME',i:'',amt:3000,txId:'T7',payDate:'06/20/2026'}];`);
  }, () => {
    eq('Ambiguous: no auto-apply', h.g('RES.length'), 0);
    eq('Ambiguous: exception type', h.g(`(EXC[0]||{}).type`), 'Ambiguous');
  });

  // ── Duplicate detection ──
  await scenario('duplicate', () => {
    h.g(`INV=[{a:'500',c:'HOOLI',i:'H1',amt:5000,dt2:'2026-06-01'}];
         PAY=[{a:'500',c:'HOOLI',i:'H1',amt:5000,txId:'DUP',payDate:'06/20/2026'},
              {a:'500',c:'HOOLI',i:'H1',amt:5000,txId:'DUP',payDate:'06/20/2026'}];`);
  }, () => {
    check('Duplicate: second payment flagged Duplicate', h.g(`EXC.some(function(e){return e.type==='Duplicate';})`), h.g('EXC.map(function(e){return e.type;})'));
  });

  // ── Unmatched: no invoice, no account context ──
  await scenario('unmatched', () => {
    h.g(`INV=[{a:'600',c:'ACME',i:'X1',amt:1000,dt2:'2026-06-01'}];
         PAY=[{a:'',c:'',i:'',po:'',amt:777,txId:'T9',payDate:'06/20/2026'}];`);
  }, () => {
    check('Unmatched: routed to Unmatched exception', h.g(`EXC.some(function(e){return e.type==='Unmatched';})`), h.g('EXC.map(function(e){return e.type;})'));
  });

  // ── Cash on Account: customer identified, no invoice, no ambiguity possible ──
  await scenario('coa', () => {
    h.g(`INV=[];
         PAY=[{a:'700',c:'WAYNE',i:'',po:'',amt:3333,txId:'T10',payDate:'06/20/2026'}];`);
  }, () => {
    check('COA: customer-identified no-invoice → Cash on Account', h.g(`EXC.some(function(e){return e.type==='Cash on Account';})`), h.g('EXC.map(function(e){return e.type;})'));
  });

  eq('no uncaught page errors', h.errors, []);
  summary('T11 all-matching-scenarios');
})().catch((e) => { console.error(e); process.exit(1); });
