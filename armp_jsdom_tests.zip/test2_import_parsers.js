// TEST 2 — Import parsers: real CSV and real XLSX through the actual upload path
const { boot, sleep, check, eq, summary } = require('./harness');
const XLSXlib = require('xlsx');

(async () => {
  const h = await boot();
  await h.login('pro');
  const w = h.window;

  // ─────────────────────────────────────────────────────────────────────
  // 2a. Invoice CSV via paste path (setImportTextSafe → processImport)
  // ─────────────────────────────────────────────────────────────────────
  const invCsv = [
    'Customer Account,Customer Name,Invoice Number,PO Number,Invoice Date,Due Date,Amount',
    '100200,ACME CORP,5100000010,PO-9001,06/01/2026,07/01/2026,"12,500.00"',
    '100200,ACME CORP,5100000011,PO-9002,06/05/2026,07/05/2026,3450.75',
    '100300,GLOBEX LLC,5100000012,PO-9003,06/10/2026,07/10/2026,899.99'
  ].join('\n');

  h.g(`IMP_TYPE='inv'; INV=[]; PAY=[]; RES=[]; EXC=[];`);
  w.setImportTextSafe(invCsv);
  w.processImport();
  await h.waitFor(() => h.g('INV.length') === 3, 8000);
  await sleep(200);

  eq('CSV: 3 invoice rows imported', h.g('INV.length'), 3);
  const inv0 = h.g(`(function(){var v=INV.find(function(x){return x.i==='5100000010';});return v?{a:v.a,c:v.c,po:v.po,amt:v.amt}:null;})()`);
  check('CSV: fields mapped (acct/cust/PO)', inv0 && inv0.a === '100200' && inv0.c === 'ACME CORP' && inv0.po === 'PO-9001', inv0);
  eq('CSV: quoted thousands amount parsed', inv0 && inv0.amt, 12500);
  eq('CSV: decimal amount parsed', h.g(`(INV.find(function(x){return x.i==='5100000011';})||{}).amt`), 3450.75);
  eq('CSV: second customer row parsed', h.g(`(INV.find(function(x){return x.i==='5100000012';})||{}).c`), 'GLOBEX LLC');

  // ─────────────────────────────────────────────────────────────────────
  // 2b. Invoice XLSX via the real file-upload path (handleFile → XLSX.read)
  // ─────────────────────────────────────────────────────────────────────
  const wsData = [
    ['Customer Account', 'Customer Name', 'Invoice Number', 'PO Number', 'Invoice Date', 'Due Date', 'Amount'],
    ['100400', 'INITECH INC', '5100000020', 'PO-7001', '06/12/2026', '07/12/2026', 25000],
    ['100400', 'INITECH INC', '5100000021', 'PO-7002', '06/15/2026', '07/15/2026', 1780.5]
  ];
  const wb = XLSXlib.utils.book_new();
  XLSXlib.utils.book_append_sheet(wb, XLSXlib.utils.aoa_to_sheet(wsData), 'Invoices');
  const xlsxBuf = XLSXlib.write(wb, { type: 'array', bookType: 'xlsx' });
  const xlsxFile = new w.File([xlsxBuf], 'open_invoices_june.xlsx', {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  });

  h.g(`IMP_TYPE='inv'; INV=[];`);
  await w.handleFile({ files: [xlsxFile], value: '' });
  await h.waitFor(() => h.g('INV.length') === 2, 8000);
  await sleep(200);

  eq('XLSX: 2 invoice rows imported from real .xlsx', h.g('INV.length'), 2);
  eq('XLSX: numeric cell amount preserved', h.g(`(INV.find(function(x){return x.i==='5100000020';})||{}).amt`), 25000);
  eq('XLSX: decimal cell amount preserved', h.g(`(INV.find(function(x){return x.i==='5100000021';})||{}).amt`), 1780.5);
  eq('XLSX: customer mapped', h.g(`(INV[0]||{}).c`), 'INITECH INC');

  // ─────────────────────────────────────────────────────────────────────
  // 2c. Bank payment CSV (IMP_TYPE='rem') → PAY rows
  // ─────────────────────────────────────────────────────────────────────
  const payCsv = [
    'Payment Date,Customer Account,Customer Name,Amount,Payment Method,Transaction ID,Invoice Number',
    '06/20/2026,100400,INITECH INC,25000.00,WIRE,TX-1001,5100000020',
    '06/21/2026,100400,INITECH INC,1780.50,ACH,TX-1002,'
  ].join('\n');
  h.g(`IMP_TYPE='rem'; PAY=[];`);
  w.setImportTextSafe(payCsv);
  w.processImport();
  await h.waitFor(() => h.g('PAY.length') === 2, 8000);
  await sleep(200);

  eq('Bank CSV: 2 payments imported', h.g('PAY.length'), 2);
  const pay0 = h.g(`(function(){var p=PAY.find(function(x){return x.txId==='TX-1001'||x.i==='5100000020';});return p?{amt:p.amt,c:p.c,a:p.a}:PAY[0]&&{amt:PAY[0].amt,c:PAY[0].c,a:PAY[0].a};})()`);
  check('Bank CSV: payment fields mapped', pay0 && pay0.amt === 25000 && /INITECH/.test(pay0.c || ''), pay0);

  // ─────────────────────────────────────────────────────────────────────
  // 2d. MUFG/YayPay-style bank XLSX auto-detection (Post Date + BAI + DETAILn)
  // ─────────────────────────────────────────────────────────────────────
  const yyData = [
    ['Post Date', 'Bank ID', 'Account Number', 'Bank Reference', 'BAI Code', 'Amount', 'DETAIL1', 'DETAIL2'],
    ['06/22/2026', '0210', '9876543', 'BR-555001', '195', 42000, 'ORIG=WAYNE ENTERPRISES', 'INV 5100000030'],
    ['06/22/2026', '0210', '9876543', 'BR-555002', '195', 1250.25, 'ORIG=STARK INDUSTRIES', '']
  ];
  const wb2 = XLSXlib.utils.book_new();
  XLSXlib.utils.book_append_sheet(wb2, XLSXlib.utils.aoa_to_sheet(yyData), 'Sheet1');
  const yyBuf = XLSXlib.write(wb2, { type: 'array', bookType: 'xlsx' });
  const yyFile = new w.File([yyBuf], 'mufg_bank_export.xlsx', {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  });

  const detected = w.detectYayPay(yyData[0]);
  eq('detectYayPay recognizes MUFG headers', detected, true);

  h.g(`IMP_TYPE='rem'; IMP_BANK_MODE=true; PAY=[];`);
  await w.handleFile({ files: [yyFile], value: '' });
  await h.waitFor(() => h.g('PAY.length') >= 2, 8000).catch(() => {});
  await sleep(200);

  eq('MUFG XLSX: 2 bank payments created', h.g('PAY.length'), 2);
  const yyAmts = h.g(`PAY.map(function(p){return p.amt;}).sort(function(a,b){return a-b;})`);
  eq('MUFG XLSX: amounts parsed', yyAmts, [1250.25, 42000]);
  const yyBankRefs = h.g(`PAY.map(function(p){return p.bankRef||p.txId||'';}).sort()`);
  check('MUFG XLSX: bank references captured', yyBankRefs.join(',').includes('555001') && yyBankRefs.join(',').includes('555002'), yyBankRefs);

  // Re-import same MUFG file — dedupe should keep PAY at 2
  await w.handleFile({ files: [yyFile], value: '' });
  await sleep(400);
  eq('MUFG XLSX: re-import dedupes (still 2 payments)', h.g('PAY.length'), 2);

  eq('no uncaught page errors', h.errors, []);
  summary('T2 import-parsers');
})().catch((e) => { console.error(e); process.exit(1); });
