// TEST 9 — Overlay-blocking regression (the production bug from browser testing):
// after login / Start fresh the setup modal covers the viewport at z-index:100,
// blocking the top-right + Invoices / + Bank File buttons and the workspace tabs.
// Verify the modal is dismissed the moment the user drives manually, so imports work.
const { boot, sleep, check, eq, summary } = require('./harness');
const fs = require('fs');

function openFullscreenOverlays(d) {
  // Overlays that cover the whole viewport with pointer-events and would block clicks
  return Array.from(d.querySelectorAll('.mo-overlay.open'))
    .filter(o => o.style.display !== 'none')
    .map(o => o.id);
}

(async () => {
  const h = await boot();
  await h.login('pro');
  const w = h.window, d = w.document;
  await sleep(300);

  // ── Repro: after fresh login the setup modal is open and covering the UI ──
  const setup = d.getElementById('armp-setup-modal');
  check('repro: setup modal open after login (covers viewport)', setup.classList.contains('open') && setup.style.display === 'flex');
  check('repro: it is a fullscreen blocking overlay', openFullscreenOverlays(d).includes('armp-setup-modal'));

  // ── FIX 1: clicking + Invoices dismisses the setup modal, opens import ──
  w.openImport('inv');
  await sleep(100);
  eq('+ Invoices dismisses the blocking setup modal', setup.classList.contains('open'), false);
  eq('setup modal display none after + Invoices', setup.style.display, 'none');
  check('import modal is now the only open overlay', openFullscreenOverlays(d).includes('imp-modal') && !openFullscreenOverlays(d).includes('armp-setup-modal'));

  // And the invoice import actually completes through this path
  w.setImportTextSafe(fs.readFileSync('/home/claude/verify/verify1_invoices_ambiguous.csv', 'utf8'));
  w.processImport();
  await h.waitFor(() => h.g('INV.length') === 4, 8000);
  eq('invoices import after modal dismissed', h.g('INV.length'), 4);

  // ── FIX 2: + Bank File also dismisses setup modal (re-open it to prove) ──
  w.armpOpenSetupModal();
  await sleep(50);
  check('setup modal re-opened for test', setup.classList.contains('open'));
  w.openImportBank();
  await sleep(100);
  eq('+ Bank File dismisses the setup modal', setup.classList.contains('open'), false);
  w.setImportTextSafe(fs.readFileSync('/home/claude/verify/verify1_payment_lump.csv', 'utf8'));
  w.processImport();
  await h.waitFor(() => h.g('PAY.length') === 1, 8000);
  eq('bank file imports after modal dismissed', h.g('PAY.length'), 1);

  // ── FIX 3: switching workspace tabs also clears a lingering setup modal ──
  w.armpOpenSetupModal();
  await sleep(50);
  check('setup modal re-opened again', setup.classList.contains('open'));
  w.setCaTab('exc', d.getElementById('ca-tab-exc'));
  await sleep(100);
  eq('switching to Needs Attention tab clears the setup modal', setup.classList.contains('open'), false);
  check('no fullscreen blocking overlay remains', openFullscreenOverlays(d).length === 0, openFullscreenOverlays(d));

  // ── End-to-end: Start fresh → import both → Auto Match → Ambiguous (not COA) ──
  // This is the exact production sequence that failed.
  w.armpOpenSetupModal();          // Start fresh reopens this
  await sleep(50);
  w.openImport('inv');             // user clicks + Invoices → modal dismissed
  await sleep(50);
  w.setImportTextSafe(fs.readFileSync('/home/claude/verify/verify1_invoices_ambiguous.csv', 'utf8'));
  h.g('INV=[];'); w.processImport();
  await h.waitFor(() => h.g('INV.length') === 4, 8000);
  w.openImportBank();
  await sleep(50);
  w.setImportTextSafe(fs.readFileSync('/home/claude/verify/verify1_payment_lump.csv', 'utf8'));
  h.g('PAY=[];'); w.processImport();
  await h.waitFor(() => h.g('PAY.length') === 1, 8000);
  await w.runMatch();
  await h.waitFor(() => h.g('EXC.length') > 0, 10000);
  await sleep(300);
  eq('end-to-end: with invoices present, engine produces Ambiguous (not COA)', h.g('EXC[0].type'), 'Ambiguous');
  eq('end-to-end: nothing auto-applied', h.g('RES.length'), 0);

  eq('no uncaught page errors', h.errors, []);
  summary('T9 overlay-blocking-fix');
})().catch((e) => { console.error(e); process.exit(1); });
